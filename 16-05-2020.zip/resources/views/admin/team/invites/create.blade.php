@extends('layouts.admin')

@section('content')


@push('styles')

<style type="text/css">

</style>


@endpush


<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6 mt-5">
        <h1 class="m-0 text-dark"><i class="fas fa-home mr-3"></i>Pending Invitations</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Invites </li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->


<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="add-property">
              <a href="{{ url('/cleaner/create') }}" class="btn btn-primary float-right">Invite cleaner</a>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="container">
              <form action="">
                <div class="row">
                  <div class="col-12">

                    <div class="form-group">
                      <label for="my-input">Select Properties</label>
                      <div class="select2-purple">
                        <select id="property_id" class="select2" name="property[]" multiple="multiple"
                          data-placeholder="Select Cleaners" data-dropdown-css-class="select2-purple"
                          style="width: 100%;">
                          @foreach($properties as $key=>$property)
                          <option value="{{ $property->id }}">{{ $property->property_name }}</option>
                          @endforeach
                        </select>

                      </div>
                    </div>
                  </div>
                  {{-- / col-12 --}}
                  @php
                  $dynamicName = "Phone Number";
                  @endphp
                  <div class="col-4">
                    <div class="form-group">
                      <label for="my-select">Method</label>
                      <select id="my-select" name="method" class="custom-select" name="">
                        <option selected disabled>Select type</option>
                        <option value="email">Email</option>
                        <option value="phone">Phone</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="form-group">
                      <label for="">Name</label>
                      <input type="text" name="" id="" class="form-control" placeholder="" aria-describedby="helpId">
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="form-group">

                    </div>
                  </div>
                </div>
              </form>
            </div>

          </div>
          <!-- /.card-body -->
        </div>
      </div>
    </div>
    <!-- /.row -->
    <!-- Main row -->
    <div class="row">
      <!-- Left col -->
      <!-- right col -->
    </div>
    <!-- /.row (main row) -->
  </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

@push('scripts')
<script>
  $(document).ready(function($) {

    $("#my-select").click(function() {
      var val = $(this).val();
      if(val == 'email')
      {
        $(this).find('form-group').append(`
        <label for="">{{ $dynamicName }}</label>
        <input type="text" name="" id="" class="form-control" placeholder="Enter Email">`);
      }else{
        $(this).find('form-group').append(`
        <label for="">{{ $dynamicName }}</label>
        <input type="phone" name="phone" id="" class="form-control" placeholder="Enter Phone" >`);
      }
    })

//Initialize Select2 Elements
$('.select2').select2();

//Initialize Select2 Elements
$('.select2bs4').select2({
  theme: 'bootstrap4'
});
  });
</script>
@endpush


@endsection