<?php

namespace App\Http\Controllers\api\admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\FilePondController;
use Illuminate\Http\Request;
use App\{User, Property , PropertyType , PropertySubTypes};
use DB;
use Validator;
use Auth;

use Illuminate\Support\Facades\Storage;
class PropertyController extends Controller
{
    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */
    
    // Fetch all Properties_types
    public function property_types()
    {
        return response()->json(['data' => PropertyType::all() , 'status' => true]);
    }
    
    // Fetch poserty sub typer by property type ID
    public function property_sub_types(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => 'required', 
            ]);
            if ($validator->fails()) { 
                return response()->json([
                    'error'=>$validator->errors()->first(),
                    'status'=>false
            ], 401);
            }
            if(PropertySubTypes::where('property_type_id' , $request->id)->exists()){
                return response()->json(['data' => PropertySubTypes::where('property_type_id' , $request->id)->get() , 'status' => true]);
            }
    }

    public function index()
    {
        if(Property::where('user_id' , Auth::user()->id )->exists() ){
            return response()->json(['data' => Property::where('user_id' , Auth::user()->id )->get() , 'status' =>true ]);
        }
    }
    
    /**
    * Show the form for creating a new resource.
    *
    * @return \Illuminate\Http\Response
    */
    public function create()
    {
        //
    }
    
    /**
    * Store a newly created resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), $this->validationRules($request));
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first() , 'status' => false ]);
        }        
        $data = new Property;
        $data->user_id = $request->user_id;
        $data->property_name = $request->property_name;
        $data->property_address = $request->property_address;
        $data->city = $request->city;
        $data->state = $request->state;
        $data->country = $request->country;
        $data->zipcode = $request->zipcode;
        $data->bathrooms = $request->bathrooms;
        $data->bedrooms = $request->bedrooms;
        $data->size = $request->size;
        $data->property_description = $request->property_description;
        if(!empty($request->base64) ){
            $imageNames = $this->imageUpload($request);
        }
        if(!$imageNames == false){
            $data->image = json_encode($imageNames);
        }
        $data->save();
        return response()->json(['message' => 'Property added successfully' , 'status' => true]);
    }
    
    // image Uploading
    
    private function imageUpload(Request $request){    
        if(!empty($request->base64)) {
            $images = $request->base64;
            $fileNames = [];
            foreach($images as $key=>$image){
                $image = str_replace('/^data:image\/[a-z]+;base64,/', '', $request->base64);
                $image = str_replace(' ', '+', $image);
                $fileName = str_random(5) . '.png';
                array_push($fileNames , $fileName);
                Storage::disk('public_driver')->put($fileName, base64_decode($image));
            }
            return $fileName;
    
            // $filepond = new FilePondController();
            // $data = $filepond->uploadImage($request);

            // return response()->json(['file' => $data,'status'=> true]);        
        }else{
            return false;
            // return response()->json(['file' => null,'status'=> false]);        
        }
    }
    
    /**
    * Display the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    public function show($id)
    {
        if(Property::find($id)->exists()){
            return response()->json(['data' => Property::find($id)->first() , 'status' =>true ]);
        }
        else{
            return response()->json(['message' => 'no data found' , 'status' =>false ]);
        }
    }
    
    /**
    * Show the form for editing the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    public function edit($id)
    {
        if(Property::find($id)->exists()){
            return response()->json(['data' => Property::find($id)->first() , 'status' =>true ]);
        }
        else{
            return response()->json(['message' => 'no data found' , 'status' =>false ]);
        }
    }
    
    /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), $this->validationRules($request));
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first() , 'status' => false ]);
        } 
        else {
            $id = ($id) ? $id : null;
            if($id){
                $data = Property::findOrFail($id);
                $data->property_name = $request->property_name;
                $data->property_address = $request->property_address;
                $data->city = $request->city;
                $data->state = $request->state;
                $data->country = $request->country;
                $data->zipcode = $request->zipcode;
                $data->bathrooms = $request->bathrooms;
                $data->bedrooms = $request->bedrooms;
                $data->size = $request->size;
                $data->property_description = $request->property_description;
                $data->save();
                return response()->json(['message' => 'Property updated successfully' , 'status' => true]);
            }
            
        }
    }
    
    /**
    * Remove the specified resource from storage.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    
    public function destroy($id)
    {
        $data = Property::find($id);
        $data->delete();
    }
    
    //Contains the form validation rules.
    private function validationRules(Request $request)
    {
        $id = $request->id;
        $validationRules = [
            'property_name' => 'required|unique:properties,property_name' .$id,
            'city' => 'required|min:2|max:20', 
            'state' => 'required|min:2|max:20', 
            'country' => 'required|min:2|max:20', 
            'zipcode' => 'required|min:4|max:12',
            'base64' => 'required'
        ];   
        
        return $validationRules;
    }
}
