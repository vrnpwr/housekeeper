<?php

namespace App\Http\Controllers;

use App\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class NotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $notifications = DB::table('notifications')->where('user_id',$user->id)->first();
        
        $options = $options = array('Notify me when guests leave early (enable in property check-in/check-out settings)','Notify me when cleaners accept my invites','Notify me when cleaners accept my projects','Notify me when one of my projects is marked as complete by a cleaner','Notify me when a cleaner asks to be removed from a project','Notify me when one of my projects is started by a cleaner','Notify me when there is a new cleaner available in my area','Notify me about events related to payments','Notify me about events related to marketplace bids and searches','Notify me about pending cleaner reviews','Remind me when my projects still don\'t have a cleaner');
        return view('admin.notification.notification',compact('user','options','notifications'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user_id =Auth::user()->id;
        $check = DB::table('notifications')->where('user_id',$user_id)->get();
        if (!count($check) == 0 ) { 
            $post_id = DB::table('notifications')->where('user_id',$user_id)->first();    
            $post_id = $post_id->id;
            $data = Notification::findOrFail($post_id);
            $data->notification = json_encode($request->notification);
            $data->email = json_encode($request->email);
            $data->mobile = json_encode($request->mobile);
            $data->sms = json_encode($request->sms);
            $data->save();
        }else{
            /* Insert Update Settings if There is no setting for user */
            $data = new Notification;
            $data->user_id = $user_id;
            $data->notification = json_encode($request->notification);
            $data->email = json_encode($request->email);
            $data->mobile = json_encode($request->mobile);
            $data->sms = json_encode($request->sms);
            $data->save();
        }
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Notification  $notification
     * @return \Illuminate\Http\Response
     */
    public function show(Notification $notification)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Notification  $notification
     * @return \Illuminate\Http\Response
     */
    public function edit(Notification $notification)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Notification  $notification
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Notification $notification)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Notification  $notification
     * @return \Illuminate\Http\Response
     */
    public function destroy(Notification $notification)
    {
        //
    }
}
