<?php

namespace App\Http\Controllers;

use App\Property;
use App\CheckList;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $properties =Property::all();
        return view('admin.property.view',compact('user','properties'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user = Auth::user();
        $checklists = CheckList::all();
        return view('admin.property.add',compact('user','checklists'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'property_name' => 'required',
            'property_address' => 'required',
            
        ]);

        if ($validator->passes()) {
            $data = new Property;
            $data->user_id = $request->input('user_id');
            $data->property_name = $request->input('property_name');
            $data->property_address = $request->input('property_address');
            $data->unit = $request->input('unit');
            $data->access_code = $request->input('access_code');
            $data->city = $request->input('city');
            $data->state = $request->input('state');
            $data->country = $request->input('country');
            $data->zipcode = $request->input('zipcode');
            $data->currency = $request->input('currency');
            $data->property_color = $request->input('colorpicker_full');
            $data->bathrooms = $request->input('bathrooms');
            $data->bedrooms = $request->input('bedrooms');
            $data->unit_of_measurement = $request->input('unit_of_measurement');
            $data->size = $request->input('size');
            $data->property_description = $request->input('property_description');
            $data->property_image = $request->input('property_image');
            $data->checklist_id = json_encode($request->input('checklist_id'));
            $data->check_in = $request->input('check_in');
            $data->check_out = $request->input('check_out');
            $data->save();
        }else{
            return response()->json(['error'=>$validator->errors()->all()]);
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function show(Property $property)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function edit(Property $property)
    {
        $user = Auth::user();
        return view('admin.property.edit',compact('user','property'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Property $property)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function destroy(Property $property)
    {
        $data = Property::find($property->id);
        $data->delete();      
    }

    public function update_property(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'property_name' => 'required',
            'property_address' => 'required',
            
        ]);

        if ($validator->passes()) {
            $data = Property::find($request->input('post_id'));
            $data->user_id = $request->input('user_id');
            $data->property_name = $request->input('property_name');
            $data->property_address = $request->input('property_address');
            $data->unit = $request->input('unit');
            $data->access_code = $request->input('access_code');
            $data->city = $request->input('city');
            $data->state = $request->input('state');
            $data->country = $request->input('country');
            $data->zipcode = $request->input('zipcode');
            $data->currency = $request->input('currency');
            $data->property_color = $request->input('colorpicker_full');
            $data->bathrooms = $request->input('bathrooms');
            $data->bedrooms = $request->input('bedrooms');
            $data->unit_of_measurement = $request->input('unit_of_measurement');
            $data->size = $request->input('size');
            $data->property_description = $request->input('property_description');
            $data->property_image = $request->input('property_image');
            $data->checklist_id = $request->input('checklist_id');
            $data->check_in = $request->input('check_in');
            $data->check_out = $request->input('check_out');
            $data->save();
        }else{
            return response()->json(['error'=>$validator->errors()->all()]);
        }


    }


}
