<div class="card-body">
	<div class="tab-content" id="general_tab_box">
		<div class="tab-pane fade show active" id="general_tab" role="tabpanel" aria-labelledby="general_tab">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<input type="hidden" value="{{ $user->id }}" id="user_id" name="">
						<label for="property_name">Property Name <span class="required">*</span></label>
						<input type="text" value="" name="property_name" id="property_name" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">


						<label for="property_address">Street Address <span class="required">*</span></label>
						<input type="text" name="property_address" value="" id="property_address" class="form-control">

					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="unit">Unit or Name</label>
						<input type="text" name="unit" value="" id="unit" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="access_code">Access Code</label>
						<input type="text" name="access_code" value="" id="access_code" class="form-control">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="city">City <span class="required">*</span></label>
						<input type="text" name="city" value="" id="city" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="state">State</label>
						<input type="text" name="state" value="" id="state" class="form-control">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="country">Country <span class="required">*</span></label>
						<input type="text" name="country" value="" id="country" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="zipcode">Zip Code</label>
						<input type="text" name="zipcode" value="" id="zipcode" class="form-control">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="currency">Currency <span class="required">*</span></label>
						<select id="currency" name="currency" class="form-control custom-select">
							<option value="inr" >INR (Indian Rupee)</option>
							<option value="euro" >EUR (EURO)</option>

						</select>

					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="property_color">Property Color</label>
						<div class="">
							<input type="text"  name="property_color" id="colorpicker-full"  class="color_picker form-control example custom-select">

						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="bedrooms">Number of Bedrooms <span class="required">*</span></label>
						<input type="text" value="" name="bedrooms" id="bedrooms" class="form-control">

					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="bathrooms">Number of Bathrooms <span class="required">*</span></label>
						<input type="text" value="" name="bathrooms" id="bathrooms" class="form-control">

					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label for="unit_of_measurement">Unit of Measurement</label>
						<select id="unit_of_measurement" name="unit_of_measurement" class="form-control custom-select">
							<option value="square_feet" >Square Feet</option>
							<option value="square_meter"  >Square Meter</option>
						</select>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">

						<label for="size">Size</label>
						<input type="text" value="" name="size" id="size" class="form-control">
					</div>
				</div>

			</div>

			<div class="row">
				<div class="col-6">
					<div class="form-group">
						<label for="property_description">Property Description (visible to cleaners)</label>
						<textarea name="property_description" id="property_description" class="form-control" rows="4"></textarea>
					</div>
				</div>
				<div class="col-6">				
					<label>Property Image</label>
					<input type="file" name="image">
					<input type="hidden" name="image1" id="image_0" value="">
				</div>
			</div>

		</div>


	</div>

	<div class="row">
		<div class="col-12">
			<button class="btn btn-success float-right" id="property-btn">Submit</button>			
		</div>
	</div>

	
</div>
<!-- /.row -->