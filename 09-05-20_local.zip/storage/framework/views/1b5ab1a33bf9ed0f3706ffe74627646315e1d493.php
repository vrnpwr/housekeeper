<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row">
	<div class="col-4">
		<div class="option">
			<?php echo e($value->title); ?>

		</div>
	</div>
	<!-- Notification Center -->
	<div class="col-2">


		<div class="custom-control custom-checkbox">			
			<!-- Hidden field to enter title in the array -->
			<input type="hidden" name="notification[<?php echo e($key); ?>][title]" 
			value="<?php echo e($value->title); ?>">
			<!-- Hidden field to enter title in the array -->
			<?php if($value->notification == 1): ?>
			<input class="custom-control-input case_notification" id="customCheckbox_<?php echo e($key); ?>" checked="" 
			type="checkbox" name="notification[<?php echo e($key); ?>][notification]" value="1">
			<label for="customCheckbox_<?php echo e($key); ?>" class="custom-control-label"></label>		
			<?php else: ?>
			<input class="custom-control-input case_notification" id="customCheckbox_<?php echo e($key); ?>" 
			type="checkbox" name="notification[<?php echo e($key); ?>][notification]" value="1">
			<label for="customCheckbox_<?php echo e($key); ?>" class="custom-control-label"></label>		
			<?php endif; ?>

		</div>
	</div>
	<!-- Notification Center -->
	<!-- Email -->

	<div class="col-2">
		<div class="custom-control custom-checkbox">
			<?php if($value->email == 1): ?>
			<input class="custom-control-input case_email" checked="" 
			id="customCheckbox__<?php echo e($key); ?>" type="checkbox" 
			name="notification[<?php echo e($key); ?>][email]"  value="1">
			<label for="customCheckbox__<?php echo e($key); ?>"  class="custom-control-label"></label>
			<?php else: ?>
			<input class="custom-control-input case_email" 
			id="customCheckbox__<?php echo e($key); ?>" type="checkbox"
			name="notification[<?php echo e($key); ?>][email]"  value="1">
			<label for="customCheckbox__<?php echo e($key); ?>"  class="custom-control-label"></label>
			<?php endif; ?>
		</div>
	</div>
	<!-- Email -->
	<!-- MObile -->

	<div class="col-2">
		<div class="custom-control custom-checkbox">
			<?php if($value->mobile == 1): ?>
			<input class="custom-control-input case_mobile" type="checkbox" id="customCheckbox___<?php echo e($key); ?>" checked="" 
			name="notification[<?php echo e($key); ?>][mobile]"  value="1">
			<label for="customCheckbox___<?php echo e($key); ?>" class="custom-control-label"></label>
			<?php else: ?>
			<input class="custom-control-input case_mobile" type="checkbox" id="customCheckbox___<?php echo e($key); ?>" name="notification[<?php echo e($key); ?>][mobile]"  value="1">
			<label for="customCheckbox___<?php echo e($key); ?>" class="custom-control-label"></label>
			<?php endif; ?>
		</div>
	</div>
	<!-- MObile -->

	<!-- Sms -->

	<div class="col-2">

		<div class="custom-control custom-checkbox">
			<?php if($value->sms == 1): ?>
			<input class="custom-control-input case_sms" type="checkbox" checked="" 
			id="customCheckbox____<?php echo e($key); ?>" name="notification[<?php echo e($key); ?>][sms]" value="1">
			<label for="customCheckbox____<?php echo e($key); ?>" class="custom-control-label"></label>
			<?php else: ?>
			<input class="custom-control-input case_sms" type="checkbox" 
			id="customCheckbox____<?php echo e($key); ?>" name="notification[<?php echo e($key); ?>][sms]" value="1">
			<label for="customCheckbox____<?php echo e($key); ?>" class="custom-control-label"></label>
			<?php endif; ?>
		</div>

	</div>
	<!-- Sms -->

</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Varun\Desktop\projects\housekeeper\resources\views/elements/notification_if.blade.php ENDPATH**/ ?>