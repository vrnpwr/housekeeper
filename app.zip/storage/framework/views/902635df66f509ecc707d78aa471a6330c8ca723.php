<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row">
	<div class="col-4">
		<div class="option">
			<?php echo e($value['title']); ?>

		</div>
	</div>
	<!-- Notification Center -->
	<div class="col-2">


		<div class="custom-control custom-checkbox">			
			<!-- Hidden field to enter title in the array -->
			<input type="hidden" name="notification[<?php echo e($key); ?>][title]" 
			value="<?php echo e($value['title']); ?>">
			<!-- Hidden field to enter title in the array -->
			<input class="custom-control-input case_notification" id="customCheckbox_<?php echo e($key); ?>" 
			type="checkbox" name="notification[<?php echo e($key); ?>][notification]" value="1">
			<label for="customCheckbox_<?php echo e($key); ?>" class="custom-control-label"></label>							

		</div>
	</div>
	<!-- Notification Center -->
	<!-- Email -->

	<div class="col-2">
		<div class="custom-control custom-checkbox">
			<input class="custom-control-input case_email" 
			id="customCheckbox__<?php echo e($key); ?>" type="checkbox"
			name="notification[<?php echo e($key); ?>][email]"  value="1">
			<label for="customCheckbox__<?php echo e($key); ?>"  class="custom-control-label"></label>
		</div>
	</div>
	<!-- Email -->
	<!-- MObile -->

	<div class="col-2">
		<div class="custom-control custom-checkbox">
			<input class="custom-control-input case_mobile" type="checkbox" id="customCheckbox___<?php echo e($key); ?>" 
			name="notification[<?php echo e($key); ?>][mobile]"  value="1">
			<label for="customCheckbox___<?php echo e($key); ?>" class="custom-control-label"></label>
		</div>
	</div>
	<!-- MObile -->

	<!-- Sms -->

	<div class="col-2">

		<div class="custom-control custom-checkbox">
			<input class="custom-control-input case_sms" type="checkbox" id="customCheckbox____<?php echo e($key); ?>" name="notification[<?php echo e($key); ?>][sms]" value="1">
			<label for="customCheckbox____<?php echo e($key); ?>" class="custom-control-label"></label>
		</div>

	</div>
	<!-- Sms -->

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Varun\Desktop\projects\housekeeper\resources\views/elements/notification_else.blade.php ENDPATH**/ ?>