<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <?php echo $__env->make('inc.header_files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed">
  <div id="app" class="wrapper">

    
    <!-- #################### Navbar ##################### -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
      </ul>
      <!-- Right navbar links -->
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
            <i class="fas fa-th-large"></i>
          </a>
        </li>
        
      </ul>
    </nav>
    <!-- #################### Navbar ##################### -->

    <!-- ######################ASIDE###################### -->
    <?php echo $__env->make('inc.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ######################ASIDE###################### -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

      <main class="">
       <?php echo $__env->yieldContent('content'); ?>
     </main>

     <footer class="main-footer">
      <strong>Copyright &copy; 2020 <a href="#">HouseKeeper</a>.</strong>
      All rights reserved.

    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

</div>

<!-- ##################FOOTERFILES################## -->
<?php echo $__env->make('inc.footer_files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ##################FOOTERFILES################## -->

</body>
</html>
<?php /**PATH C:\Users\Varun\Desktop\projects\housekeeper\resources\views/layouts/admin.blade.php ENDPATH**/ ?>