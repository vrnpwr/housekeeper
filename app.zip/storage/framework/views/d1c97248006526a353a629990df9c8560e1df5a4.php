								<div class="card-body">
									<form method="post" enctype="multipart/form-data">
										<div class="tab-content" id="general_tab_box">
											<div class="tab-pane fade show active" id="general_tab" role="tabpanel" aria-labelledby="general_tab">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="property_name">Property Name <span class="required">*</span></label>
															<input type="text" value="" name="property_name" id="property_name" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">


															<label for="property_address">Street Address <span class="required">*</span></label>
															<input type="text" name="property_address" value="" id="property_address" class="form-control">

														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="unit">Unit or Name</label>
															<input type="text" name="unit" value="" id="unit" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="access_code">Access Code</label>
															<input type="text" name="access_code" value="" id="access_code" class="form-control">
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="city">City <span class="required">*</span></label>
															<input type="text" name="city" value="" id="city" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="state">State</label>
															<input type="text" name="state" value="" id="state" class="form-control">
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="country">Country <span class="required">*</span></label>
															<input type="text" name="country" value="" id="country" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="zipcode">Zip Code</label>
															<input type="text" name="zipcode" value="" id="zipcode" class="form-control">
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="currency">Currency <span class="required">*</span></label>
															<select name="currency" class="form-control custom-select">
																<option value="inr" >INR (Indian Rupee)</option>
																<option value="euro" >EUR (EURO)</option>

															</select>

														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="property_color">Property Color</label>
															<div class="">
																<input type="text"  value="" name="property_color" id="colorpicker-full"  class="color_picker form-control custom-select">
																<span class="color_property" style="background-color:;"> </span>

															</div>
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-md-4">
														<div class="form-group">
															<label for="bedrooms">Number of Bedrooms <span class="required">*</span></label>
															<input type="text" value="" name="bedrooms" id="bedrooms" class="form-control">

														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group">
															<label for="bathrooms">Number of Bathrooms <span class="required">*</span></label>
															<input type="text" value="" name="bathrooms" id="bathrooms" class="form-control">

														</div>
													</div>
													<div class="col-md-2">
														<div class="form-group">
															<label for="unit_of_measurement">Unit of Measurement</label>
															<select name="unit_of_measurement" class="form-control custom-select">
																<option value="square_feet" >Square Feet</option>
																<option value="square_meter"  >Square Meter</option>
															</select>
														</div>
													</div>
													<div class="col-md-2">
														<div class="form-group">

															<label for="size">Size</label>
															<input type="text" value="" name="size" id="size" class="form-control">
														</div>
													</div>

												</div>

												<div class="row">
													<div class="col-md-12">
														<div class="form-group">
															<label for="property_description">Property Description (visible to cleaners)</label>
															<textarea name="property_description" id="property_description" class="form-control" rows="4"></textarea>
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-md-6">


														<div class="form-group">
															<label for="exampleInputFile">Property Image</label>

											<!--<label for="imageUpload" id="label_file">
												  <div class="avatar-upload">
													<div class="avatar-edit">
														
														<input type='file' name="property_image" id="imageUpload" accept=".png, .jpg, .jpeg" />
														
													</div>
													<div class="avatar-preview">
														<div id="imagePreview" style="background-image: url('http://brotherslab.com/housekeeper/assets/img/6.png');">
														</div>
													</div>
												</div>
											</label>
										-->
										<div class="input-group">
											<div class="custom-file">
												<input type="file" name="property_image" class="custom-file-input" id="exampleInputFile">
												<label class="custom-file-label" for="exampleInputFile">Choose file</label>
											</div>

										</div>

									</div>
								</div>
							</div>

						</div>


						<div class="tab-pane fade" id="checklists_tab" role="tabpanel" aria-labelledby="checklists_tab">

							<h6><b>You currently have 4 checklists.</b></h6>
							<p>Current active checklist</p>
							<ul class="list_checklists">
								<li>
									<b>rooms</b>
									<p> Created at: 23/03/2020 Total items: 1 Properties using it: Urban Estate Phase 2 Rd Phase 2, Urban Estate Phase 2 Rd Phase 1, Home 
										<span class="radio_switch">
											<label class="el-switch">
												<input type="radio" value="11" name="checklist_id" >
												<span class="el-switch-style"></span>
											</label>


										</span> </p>
									</li>
									<li>
										<b>test</b>
										<p> Created at: 20/02/2020 Total items: 2 Properties using it: Urban Estate Phase 2 Rd Phase 1 
											<span class="radio_switch">
												<label class="el-switch">
													<input type="radio" value="9" name="checklist_id" >
													<span class="el-switch-style"></span>
												</label>


											</span> </p>
										</li>
										<li>
											<b>test at 23 march</b>
											<p> Created at: 23/03/2020 Total items: 2  
												<span class="radio_switch">
													<label class="el-switch">
														<input type="radio" value="10" name="checklist_id" >
														<span class="el-switch-style"></span>
													</label>


												</span> </p>
											</li>
											<li>
												<b>Sleepover,'s checklist</b>
												<p> Created at: 18/02/2020 Total items: 2 Properties using it: Urban Estate Phase 2 Rd Phase 2, , Urban Estate Phase 2 Rd Phase 1 
													<span class="radio_switch">
														<label class="el-switch">
															<input type="radio" value="5" name="checklist_id" >
															<span class="el-switch-style"></span>
														</label>


													</span> </p>
												</li>


											</ul>

										</div>

										<div class="tab-pane fade" id="check_in_and_checkout" role="tabpanel" aria-labelledby="check_in_and_checkout">
											<h5>Check-In/Check-Out Times</h5>
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label for="check_in">Check In</label>
														<input type="text" value="" name="check_in" id="check_in" class="form-control timepicker">

													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group">


														<label for="check_out">Check Out</label>
														<input type="text" name="check_out" value="" id="check_out" class="form-control timepicker">

													</div>
												</div>
											</div>

										</div>

									</div>

									<div class="row">
										<div class="col-12">

											<input type="submit" value="Submit" name="submit" class="btn btn-success float-right">
										</div>
									</div>

								</form>

							</div>
							<!-- /.row --><?php /**PATH C:\Users\Varun\Desktop\projects\housekeeping\resources\views/forms/property/general.blade.php ENDPATH**/ ?>